"""Benchmark utilities."""
